﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.ComponentModel.Design;
using lab11;
using static System.Windows.Forms.LinkLabel;

namespace lab11
{
    public partial class Form2 : Form
    {
        public static Form3 Form3 { get; set; }
        private string login;
        public Form2(string login)
        {
            InitializeComponent();
            this.login = login;
        }
        private void Form2_Load(object sender, EventArgs e)
        {
            using (buyerContext db = new buyerContext())
            {
                foreach (buyer rinok in db.Buyers)
                {
                    if (login == rinok.Login)
                    {
                        textBox1.Text = rinok.Login;
                        textBox2.Text = rinok.Surname;
                        textBox3.Text = rinok.Name;
                        textBox4.Text = rinok.MusicDirection;
                        textBox5.Text = rinok.Phone;
                        textBox6.Text = rinok.DataOfBirth;
                        textBox7.Text = rinok.DateOfTheFirstV;
                        textBox8.Text = rinok.Email;

                    }
                }
                db.SaveChanges();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            this.Hide();
            form1.ShowDialog();
        }
    }
}

