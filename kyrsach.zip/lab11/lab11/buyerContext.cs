﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Data.Entity;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;

namespace lab11
{
    public class buyerContext : DbContext
    {
        public buyerContext() : base("DbConnection") { }
        public DbSet<buyer> Buyers { get; set; }

    }
}
