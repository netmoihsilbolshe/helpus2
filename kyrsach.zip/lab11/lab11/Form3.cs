﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.ComponentModel.Design;
using lab11;

namespace lab11
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private string GeneratePass()
        {
            string iPass = "";
            char[] arr = { '1', '2', '3', '4', '5', '6', '7', '8', '9', 'B', 'C', 'D', 'F', 'G', 'H', 'J', 'K', 'L', 'M', 'N', 'P', 'Q', 'R', 'S', 'T', 'V', 'W', 'X', 'Z', 'b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'm', 'n', 'p', 'q', 'r', 's', 't', 'v', 'w', 'x', 'z', 'A', 'E', 'U', 'Y', 'a', 'e', 'i', 'o', 'u', 'y' };
            Random rnd = new Random();
            for (int i = 0; i < 10; i++)
            {

                iPass = iPass + arr[rnd.Next(0, 57)].ToString();
            }
            return iPass;
        }
        private string GetHashString(string s)
        {
            byte[] bytes = Encoding.Unicode.GetBytes(s);
            MD5CryptoServiceProvider CSP = new MD5CryptoServiceProvider();
            byte[] byteHash = CSP.ComputeHash(bytes);
            string hash = "";
            foreach (byte b in byteHash)
            {
                hash += string.Format("{0:x2}", b);
            }
            return hash;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                MailAddress from = new MailAddress("aaaaa-jenshina@mail.ru", "Arina");
                MailAddress to = new MailAddress(textBoxeEmail.Text);
                MailMessage m = new MailMessage(from, to);
                m.Subject = "Восстановление пароля: ";
                using (buyerContext db = new buyerContext())
                {
                    foreach (buyer designer in db.Buyers) 
                    {
                        if (textBoxeEmail.Text == designer.Email)
                        {
                            string newPassword = GeneratePass();

                            m.Body = "<h1>Пароль: " + newPassword + "</h1>";
                            designer.Password = GetHashString(newPassword);
                            MessageBox.Show("Пароль отправлен на почту");
                        }
                    }
                    db.SaveChanges();
                }
                SmtpClient smtp = new SmtpClient("smtp.mail.ru", 587); 
                m.IsBodyHtml = true;
                smtp.Credentials = new  NetworkCredential("aaaaa-jenshina@mail.ru", "2ZjQf09qhX2sd93f8T6F"); 
                smtp.EnableSsl = true;
                smtp.Send(m);
            }
            catch
            {
                MessageBox.Show("Не получилось отправить пароль(");
            }
        }


      
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form1 form1 = new Form1();
            this.Hide();
            form1.ShowDialog();
        }
    }

}
